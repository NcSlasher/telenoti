#!/bin/bash

# Telegram Bot
TELEGRAM_BOT_TOKEN="6239675226:AAGe5NBXBVUmjYsfDZyRETBRxQFiBh2--R8"
TELEGRAM_CHAT_ID="1369660330"

# กำหนด Port ที่ต้องการตรวจสอบ
PORT=443

# ส่งข้อความแจ้งเตือนเมื่อมีการเข้าถึง
send_telegram_notify() {
    local msg="$1"
    curl -s -X POST "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/sendMessage" -d "chat_id=$TELEGRAM_CHAT_ID&text=$msg"
}

# ตรวจสอบการเข้าถึงข้อมูลที่เซิร์ฟเวอร์
while read line; do
    ip_address=$(echo $line | awk '{print $2}')
    msg="มีการเข้าถึงข้อมูลที่เซิร์ฟเวอร์จาก IP: $ip_address"
    send_telegram_notify "$msg"
done < <(sudo ngrep -q -W byline -d any "tcp dst port $PORT" 2>/dev/null)
